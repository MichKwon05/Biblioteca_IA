package mx.edu.utez.biblioteca.controlador.usuario;

import mx.edu.utez.biblioteca.modelo.usuario.Usuario;
import mx.edu.utez.biblioteca.servicio.usuario.UsuarioService;
import mx.edu.utez.biblioteca.utliles.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/usuario")
@CrossOrigin(origins = {"*"})
public class UsuarioController {
    @Autowired
    private UsuarioService service;

    //http://localhost:8080/api/usuario/

    @GetMapping("/")
    public ResponseEntity<Response<List<Usuario>>> getAll() {
        return new ResponseEntity<>(
                this.service.getAll(), HttpStatus.OK
        );
    }
}
