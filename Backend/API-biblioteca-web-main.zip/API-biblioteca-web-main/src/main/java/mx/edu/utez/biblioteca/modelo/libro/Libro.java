package mx.edu.utez.biblioteca.modelo.libro;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "libros")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Libro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_libro;
    @Column(nullable = false, length = 100)
    private String titulo;
    @Column(nullable = false, length = 100)
    private String autor;
    @Column(nullable = false, length = 100)
    private String genero;
    @Column(nullable = false)
    private String anio;
    @Column(nullable = false, length = 200)
    private String descripcion;
    @Column(nullable = false, columnDefinition = "boolean default true")
    @JsonIgnore
    private Boolean estatus;
}
