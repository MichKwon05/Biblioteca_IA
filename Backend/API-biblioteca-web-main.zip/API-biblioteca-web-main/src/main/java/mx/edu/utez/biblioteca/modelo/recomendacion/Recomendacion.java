package mx.edu.utez.biblioteca.modelo.recomendacion;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.biblioteca.modelo.usuario.Usuario;

import java.util.Date;

@Entity
@Table(name = "recomendaciones")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Recomendacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_recomendacion;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(nullable = false, length = 150)
    private Date dia_creacion;

    @Column(nullable = false,columnDefinition = "TINYINT DEFAULT 1")
    private Boolean estatus;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

}
