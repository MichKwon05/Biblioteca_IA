package mx.edu.utez.biblioteca.modelo.renta;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.biblioteca.modelo.libro.Libro;
import mx.edu.utez.biblioteca.modelo.usuario.Usuario;

import java.util.Date;

@Entity
@Table(name = "rentas")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Renta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_renta;

    @Column(nullable = false)
    private Date fecha_inicio;

    @Column(nullable = false)
    private Date fecha_fin;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "id_libro")
    private Libro libro;

    @Column(nullable = false, columnDefinition = "boolean default true")
    @JsonIgnore
    private Boolean estatus;
}
