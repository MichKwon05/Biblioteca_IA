package mx.edu.utez.biblioteca.modelo.rol;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.biblioteca.modelo.usuario.Usuario;

import java.util.Set;

@Entity
@Table(name = "roles")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Rol {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_rol;

    @Column(nullable = false, length = 100)
    private String nombre_rol;

    @Column(nullable = false, columnDefinition = "boolean default true")
    @JsonIgnore
    private Boolean estatus;
    @OneToMany(mappedBy = "rol")
    @JsonIgnore
    private Set<Usuario> usuario;

}
