package mx.edu.utez.biblioteca.modelo.rol;

import mx.edu.utez.biblioteca.modelo.recomendacion.Recomendacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RolRepository extends JpaRepository<Rol, Integer> {
}
