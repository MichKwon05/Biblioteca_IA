package mx.edu.utez.biblioteca.modelo.usuario;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.biblioteca.modelo.personalizacion.Personalizacion;
import mx.edu.utez.biblioteca.modelo.rol.Rol;

@Entity
@Table(name = "usuarios")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_usuario;
    @Column(nullable = false, length = 200)
    private String nombre;
    @Column(nullable = false, length = 200)
    private String apellidos;
    @Column(nullable = false, length = 100)
    private String correo;
    @Column(nullable = false, length = 200)
    private String contrasena;
    @Column(nullable = false, length = 10)
    private Integer telefono;
    @ManyToOne
    @JoinColumn(name = "id_rol")
    private Rol rol;
    @Column(nullable = false, columnDefinition = "boolean default true")
    @JsonIgnore
    private Boolean estatus;
    @OneToOne
    @JoinColumn(name = "id_personalizacion")
    @JsonIgnore
    private Personalizacion personalizacion;
}
