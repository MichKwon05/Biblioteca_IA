package mx.edu.utez.biblioteca.modelo.vistas;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Entity
@Table(name = "vistas")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Vistas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_visita;

    @Column(nullable = false, length = 100)
    private Integer numero_visitas;
    @Column(nullable = false, length = 100)
    private Date fecha_creacion;
    @Column(nullable = false, columnDefinition = "boolean default true")
    @JsonIgnore
    private Boolean estatus;
}
