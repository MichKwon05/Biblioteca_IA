package mx.edu.utez.biblioteca.modelo.vistas;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VistasRepository extends JpaRepository<Vistas, Integer> {
}
