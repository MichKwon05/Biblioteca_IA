package mx.edu.utez.biblioteca.servicio.usuario;

import mx.edu.utez.biblioteca.modelo.rol.RolRepository;
import mx.edu.utez.biblioteca.modelo.usuario.Usuario;
import mx.edu.utez.biblioteca.modelo.usuario.UsuarioRepository;
import mx.edu.utez.biblioteca.utliles.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UsuarioService {
    @Autowired
    private UsuarioRepository repository;

    @Transactional(readOnly = true)
    public Response<List<Usuario>> getAll(){
        return new Response<>(
                this.repository.findAll(), false, 200, "Correcto"
        );
    }
}
